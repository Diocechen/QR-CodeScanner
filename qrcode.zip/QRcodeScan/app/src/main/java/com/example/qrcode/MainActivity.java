package com.example.qrcode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {
    Button ScanButton;

    TextView Result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ScanButton = findViewById(R.id.button_QRScan);
        Result = findViewById(R.id.textView_Result);

        //設置監聽
        ScanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator intentIntegrator = new IntentIntegrator(MainActivity.this);
                //IntentIntegrator 它是用於方便地處理 Intent-based 條碼掃描的工具類。
                intentIntegrator.setPrompt("Scan a QR-Code");
                //提示
                intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
                //設置要掃描的條碼類型
                intentIntegrator.initiateScan();
                //呼叫相機進行掃描
            }
        });
    }

    //onActivityResult 是一個用於處理活動（Activity）之間數據交互的方法。
    // 當一個活動（Activity）啟動了另一個活動（Activity），並且在後者的操作完成後返回到前者時，onActivityResult 方法會被調用。
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        //requestCode 是你在啟動掃瞄器活動時指定的請求代碼。它用於識別不同的請求，以便在 onActivityResult 方法中區分不同的結果。
        //resultCode 是掃瞄器活動的操作結果，通常有三個預設值：RESULT_OK、RESULT_CANCELED 和 RESULT_FIRST_USER。
        //data 是返回結果的 Intent 對象，其中包含掃瞄器活動返回的數據，如掃瞄到的 QR-Code 信息。

        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        //IntentIntegrator.parseActivityResult 方法是 ZXing 提供的一個靜態方法，用於解析活動返回的結果。
        //IntentResult 封裝解析後的掃描結果。

        if(intentResult != null){
            String content = intentResult.getContents();
            if(content != null){
                Result.setText(content);
            }
        }else{
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}